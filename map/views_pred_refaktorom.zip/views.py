from django.shortcuts import render
import folium
import geocoder
import random
import json
import psycopg2
import psycopg2.extras
from folium import plugins
from draw_custom import Draw as Draw_custom
from django.shortcuts import render, redirect
from .forms import NewUserForm
from django.contrib.auth import login
from django.contrib import messages
from django.contrib.auth.models import User
from django.contrib.auth import get_user_model
from friendship.models import Friend, Follow, Block, FriendshipRequest
conn = psycopg2.connect(
    host="localhost",
    database="mapa",
    user="postgres",
    password="123456789",
    options="-c search_path=public")
cur = conn.cursor()


def farba_2(features):
    return {
        'fillColor': 'orange',
        'color': 'orange',
    }


def farba_3(features):
    return {
        'fillColor': 'red',
        'color': 'red',
    }


def farba_4(features):
    return {
        'fillColor': '#82152D',
        'color': '#82152D',
    }


def farba_5(features):
    return {
        'fillColor': 'black',
        'color': 'black',
    }


def index(requests):
    # Tu capnem mapu
    lokacia = geocoder.osm('SK')
    m = folium.Map(location=[48.73044030054515, 19.456582270083356],
                   zoom_start=9,
                   width=1000, height=800,
                   prefer_canvas=True,
                   # crs="EPSG3857",

                   )
    skupina_v_navigacii = dict()
    # stupne_ochrany
    chranene_oblasti_db = cur.execute('SELECT id,meno,st_asgeojson(polygon),popis FROM "stupen_ochrany";')
    chranene_oblasti_db = cur.fetchall()
    chranene_oblasti = folium.FeatureGroup("Chránené oblasti", control=False)
    druhy_stupen = folium.plugins.FeatureGroupSubGroup(chranene_oblasti, name="II. stupeň ochrany")
    treti_stupen = folium.plugins.FeatureGroupSubGroup(chranene_oblasti, name='III. stupeň ochrany')
    stvrty_stupen = folium.plugins.FeatureGroupSubGroup(chranene_oblasti, name="IV. stupeň ochrany")
    piaty_stupen = folium.plugins.FeatureGroupSubGroup(chranene_oblasti, name="V. stupeň ochrany")
    m.add_child(chranene_oblasti)
    m.add_child(druhy_stupen)
    m.add_child(treti_stupen)
    m.add_child(stvrty_stupen)
    m.add_child(piaty_stupen)
    skupina_v_navigacii['Stupne ochrany'] = [druhy_stupen, treti_stupen, stvrty_stupen, piaty_stupen]
    for i in chranene_oblasti_db:  # rozdeliť do viacerých cyklov, aby V. stupeň bol vždy na vrchu
        html = f"""
            <b>{i[1].split("- ")[1]}</b><br> 
                <a href="https://www.slovensko.sk/sk/agendy/agenda/_uzemna-ochrana-prirody-a-kraji" target="_blank" rel="noopener noreferrer">Pravidlá v tejto oblasti</a>
                <br> 
                <a href="forum/{i[0]}" target="_blank" rel="noopener noreferrer">Diskusia</a>
            """
        if (i[1] == 'Zóna A - V. stupeň ochrany'):
            folium.GeoJson(i[2], style_function=farba_5).add_to(piaty_stupen).add_child(
                folium.Popup(folium.Html(html, script=True)))
        elif (i[1] == 'Zóna B - IV. stupeň ochrany'):
            folium.GeoJson(i[2], style_function=farba_4).add_to(stvrty_stupen).add_child(
                folium.Popup(folium.Html(html, script=True)))
        elif (i[1] == 'Zóna C - III. stupeň ochrany'):
            folium.GeoJson(i[2], style_function=farba_3).add_to(treti_stupen).add_child(
                folium.Popup(folium.Html(html, script=True)))
        elif (i[1] == 'Zóna D - II. stupeň ochrany'):
            folium.GeoJson(i[2], style_function=farba_2).add_to(druhy_stupen).add_child(
                folium.Popup(folium.Html(html, script=True)))

    # chránené územia
    def osetrenie_zon(text):  # keďže v db majú rôzne označenie pre zóny, treba to akosi zúhľadniť
        try:
            text = str(text).split("- ")[1]
            return text
        except:
            pass
        if text == "Neaplikuje sa":
            return text
        if "5" in text:
            return "V. stupeň ochrany"
        elif "4" in text:
            return "IV. stupeň ochrany"
        elif "3" in text:
            return "III. stupeň ochrany"
        elif "2" in text:
            return "II. stupeň ochrany"
        if "C" in text:
            return "III. stupeň ochrany"
        if "B" in text:
            return "IV. stupeň ochrany"
        return text  # tu by som sa nikdy nemal dostať

    rezervacie_db = cur.execute(
        'SELECT id,csz,nam,psb,zona,legenda,typ_mchu,dts,leg,aktualne_k,rok_vyhl,vyhlasil,kn,st_asgeojson(polygon) FROM "chranene_oblasti";')
    rezervacie_db = cur.fetchall()
    rezervacie = folium.FeatureGroup("Chránené územia", control=False)
    pamiatka = folium.plugins.FeatureGroupSubGroup(rezervacie, name="Prírodná pamiatka")
    narodna_pamiatka = folium.plugins.FeatureGroupSubGroup(rezervacie, name='Národná prírodná pamiatka')
    prirodna_rezervacia = folium.plugins.FeatureGroupSubGroup(rezervacie, name="Prírodná rezervácia")
    sukromna_prirodna_rezervacia = folium.plugins.FeatureGroupSubGroup(rezervacie, name="Súkromná prírodná rezervácia")
    narodna_prirodna_rezervacia = folium.plugins.FeatureGroupSubGroup(rezervacie, name="Národná prírodná rezervácia")
    chraneny_krajinny_prvok = folium.plugins.FeatureGroupSubGroup(rezervacie, name="Chránený krajinný prvok")
    ochranne_pasmo_prirodnej_rezervacie = folium.plugins.FeatureGroupSubGroup(rezervacie,
                                                                              name="Ochranné pásmo prírodnej rezervácie")
    ochranne_pasmo__narodnej_prirodnej_rezervacie = folium.plugins.FeatureGroupSubGroup(rezervacie,
                                                                                        name="Ochranné pásmo národnej prírodnej rezervácie")
    ochranne_pasmo_prirodnej_pamiatky = folium.plugins.FeatureGroupSubGroup(rezervacie,
                                                                            name="Ochranné pásmo prírodnej pamiatky")
    ochranne_pasmo_prirodnej_narodnej_pamiatky = folium.plugins.FeatureGroupSubGroup(rezervacie,
                                                                                     name="Ochranné pásmo národnej prírodnej pamiatky")
    chraneny_areal = folium.plugins.FeatureGroupSubGroup(rezervacie, name="Chránený areál")
    ochranne_pasmo_chraneneho_arealu = folium.plugins.FeatureGroupSubGroup(rezervacie,
                                                                           name="Ochranné pásmo chráneného areálu")
    m.add_child(rezervacie)
    m.add_child(pamiatka)
    m.add_child(narodna_pamiatka)
    m.add_child(ochranne_pasmo_prirodnej_pamiatky)
    m.add_child(ochranne_pasmo_prirodnej_narodnej_pamiatky)
    skupina_v_navigacii['Pamiatky'] = [pamiatka, narodna_pamiatka, ochranne_pasmo_prirodnej_pamiatky,
                                       ochranne_pasmo_prirodnej_narodnej_pamiatky]
    m.add_child(prirodna_rezervacia)
    m.add_child(sukromna_prirodna_rezervacia)
    m.add_child(narodna_prirodna_rezervacia)
    m.add_child(ochranne_pasmo_prirodnej_rezervacie)
    m.add_child(ochranne_pasmo__narodnej_prirodnej_rezervacie)
    skupina_v_navigacii['Rezervácie'] = [prirodna_rezervacia, sukromna_prirodna_rezervacia, narodna_prirodna_rezervacia,
                                         ochranne_pasmo_prirodnej_rezervacie,
                                         ochranne_pasmo__narodnej_prirodnej_rezervacie]
    m.add_child(chraneny_areal)
    m.add_child(ochranne_pasmo_chraneneho_arealu)
    m.add_child(chraneny_krajinny_prvok)
    skupina_v_navigacii['Iné chránené oblasti'] = [chraneny_areal, ochranne_pasmo_chraneneho_arealu,
                                                   chraneny_krajinny_prvok]
    for i in rezervacie_db:
        html = f"""
            <b>{i[5]}</b><br> 
            {osetrenie_zon(i[4])}<br> 
                <a href="https://www.slovensko.sk/sk/agendy/agenda/_narodne-parky-a-prirodne-rezer/" target="_blank" rel="noopener noreferrer">Pravidlá v tejto oblasti</a>
                <br> 
                <a href="forum/{i[0]}" target="_blank" rel="noopener noreferrer">Diskusia</a>
            """
        if (i[6] == 'Národná prírodná rezervácia'):
            def farba(features):
                return {
                    'fillColor': 'royalblue',
                    'color': 'royalblue',
                }

            folium.GeoJson(i[13], style_function=farba).add_to(narodna_prirodna_rezervacia).add_child(
                folium.Popup(folium.Html(html, script=True)))
        elif (i[6] == 'Národná prírodná pamiatka'):
            def farba(features):
                return {
                    'fillColor': 'indigo',
                    'color': 'indigo',
                }

            folium.GeoJson(i[13], style_function=farba).add_to(narodna_pamiatka).add_child(
                folium.Popup(folium.Html(html, script=True)))
        elif (i[6] == 'Súkromná prírodná rezervácia'):
            def farba(features):
                return {
                    'fillColor': 'cornflowerblue',
                    'color': 'cornflowerblue',
                }

            folium.GeoJson(i[13], style_function=farba).add_to(sukromna_prirodna_rezervacia).add_child(
                folium.Popup(folium.Html(html, script=True)))
        elif (i[6] == 'Prírodná pamiatka'):
            def farba(features):
                return {
                    'fillColor': 'saddlebrown',
                    'color': 'saddlebrown',
                }

            folium.GeoJson(i[13], style_function=farba).add_to(pamiatka).add_child(
                folium.Popup(folium.Html(html, script=True)))
        elif (i[6] == 'Prírodná rezervácia'):
            def farba(features):
                return {
                    'fillColor': 'deepskyblue',
                    'color': 'deepskyblue',
                }

            folium.GeoJson(i[13], style_function=farba).add_to(prirodna_rezervacia).add_child(
                folium.Popup(folium.Html(html, script=True)))
        elif (i[6] == 'Chránený krajinný prvok'):
            def farba(features):
                return {
                    'fillColor': 'greenyellow',
                    'color': 'greenyellow',
                }

            folium.GeoJson(i[13], style_function=farba).add_to(chraneny_krajinny_prvok).add_child(
                folium.Popup(folium.Html(html, script=True)))
        elif (i[6] == 'Ochranné pásmo prírodnej rezervácie'):
            def farba(features):
                return {
                    'fillColor': 'yellowgreen',
                    'color': 'yellowgreen',
                }

            folium.GeoJson(i[13], style_function=farba).add_to(ochranne_pasmo_prirodnej_rezervacie).add_child(
                folium.Popup(folium.Html(html, script=True)))
        elif (i[6] == 'Ochranné pásmo národnej prírodnej rezervácie'):
            def farba(features):
                return {
                    'fillColor': 'olive',
                    'color': 'olive',
                }

            folium.GeoJson(i[13], style_function=farba).add_to(ochranne_pasmo__narodnej_prirodnej_rezervacie).add_child(
                folium.Popup(folium.Html(html, script=True)))
        elif (i[6] == 'Ochranné pásmo prírodnej pamiatky'):
            def farba(features):
                return {
                    'fillColor': 'chocolate',
                    'color': 'chocolate',
                }

            folium.GeoJson(i[13], style_function=farba).add_to(ochranne_pasmo_prirodnej_pamiatky).add_child(
                folium.Popup(folium.Html(html, script=True)))
        elif (i[6] == 'Ochranné pásmo národnej prírodnej pamiatky'):
            def farba(features):
                return {
                    'fillColor': 'burlywood',
                    'color': 'burlywood',
                }

            folium.GeoJson(i[13], style_function=farba).add_to(ochranne_pasmo_prirodnej_narodnej_pamiatky).add_child(
                folium.Popup(folium.Html(html, script=True)))
        elif (i[6] == 'Chránený areál'):
            def farba(features):
                return {
                    'fillColor': 'mediumseagreen',
                    'color': 'mediumseagreen',
                }

            folium.GeoJson(i[13], style_function=farba).add_to(chraneny_areal).add_child(
                folium.Popup(folium.Html(html, script=True)))
        elif (i[6] == 'Ochranné pásmo chráneného areálu'):
            def farba(features):
                return {
                    'fillColor': 'g',
                    'color': 'g',
                }

            folium.GeoJson(i[13], style_function=farba).add_to(ochranne_pasmo_chraneneho_arealu).add_child(
                folium.Popup(folium.Html(html, script=True)))

    # Uzemia europskeho významu
    euro_uzemia_db = cur.execute(
        'SELECT id,sitecode,nazov_uzem,pracovisko,etapa,st_asgeojson(polygon) FROM "uzemia_euro_vyznamu";')
    euro_uzemia_db = cur.fetchall()
    euro_uzemia = folium.FeatureGroup("Územia európskeho významu", control=False)
    uzemia_europskeho_vyznamu = folium.plugins.FeatureGroupSubGroup(euro_uzemia, name="Územia európskeho významu",
                                                                    show=False)
    skupina_v_navigacii['Územia európskeho významu'] = [uzemia_europskeho_vyznamu]
    m.add_child(euro_uzemia)
    m.add_child(uzemia_europskeho_vyznamu)
    for i in euro_uzemia_db:
        html = f"""
               <b>{i[2]}</b><br> 

                   <a href="https://www.slovensko.sk/sk/agendy/agenda/_narodne-parky-a-prirodne-rezer/" target="_blank" rel="noopener noreferrer">Pravidlá v tejto oblasti</a>
                   <br> 
                   <a href="forum/{i[0]}" target="_blank" rel="noopener noreferrer">Diskusia</a>
               """

        def farba(features):
            return {
                'fillColor': '#003399',
                'color': '#003399',
            }

        folium.GeoJson(i[5], style_function=farba).add_to(uzemia_europskeho_vyznamu).add_child(
            folium.Popup(folium.Html(html, script=True)))

    #Pridanie objektu užívateľom:
    if (requests.GET.get('new_object') != None and requests.GET.get('new_object_name')!=None):
        dictData = json.loads(requests.GET.get('new_object'))
        INSERT_STATEMENT = 'INSERT INTO vlastne_objekty (username,geometry,name) VALUES (%s, ST_SetSRID(ST_GeomFromGeoJSON(%s), 4326), %s);'
        cur.execute(INSERT_STATEMENT, (requests.user.username, str(dictData['geometry']), requests.GET.get('new_object_name')))
        cur.execute("COMMIT")

    # Objekty pridané užívateľom
    if requests.user.is_authenticated:
        vlastne_objekty_db = cur.execute(
            'SELECT id,username,st_asgeojson(geometry),name FROM "vlastne_objekty";')
        vlastne_objekty_db = cur.fetchall()
        vlastne_objekty_navigacia = []
        for i in vlastne_objekty_db:
            html = f"""
                      <b>{i[3]}</b><br> 
    
                        Pridal: {i[1]}
                      """

            def farba(features):
                return {
                    'fillColor': 'white',
                    'color': 'white',
                }

            fg1 = folium.map.FeatureGroup(name=i[3], show=True)
            folium.GeoJson(i[2], style_function=farba).add_to(fg1).add_child(
                folium.Popup(folium.Html(html, script=True)))
            fg1.add_to(m)
            vlastne_objekty_navigacia.append(fg1)
        skupina_v_navigacii["Vlastné objekty:"] = vlastne_objekty_navigacia

    # mapa nastavenie
    folium.plugins.Fullscreen().add_to(m)
    folium.plugins.Geocoder(collapsed=True, add_marker=True).add_to(m)
    # folium.LayerControl().add_to(m)
    folium.plugins.GroupedLayerControl(skupina_v_navigacii, exclusive_groups=False).add_to(m)
    folium.plugins.LocateControl(auto_start=True).add_to(m)
    if(requests.user.is_authenticated):
        Draw_custom(export=False).add_to(m)
    m = m._repr_html_()
    context = {
        'm': m,
    }
    return render(requests, 'index.html', context)


# Koniec mapy, začiatok diskusného fóra
def forum(requests):
    return render(requests, 'forum/index.html')


def friends_main_page(requests):
    if requests.user.is_authenticated == False:
        return render(requests, 'friends/index.html')
    context = {}
    user_search = []
    if(requests.GET.get('search') != None):
        for i in get_user_model().objects.all():
            uz_odoslane = False  # kontrola, či už náhodou žiadosť nebola poslaná
            if (requests.user.get_username()==i.get_username()):
                continue
            if str(i.get_username()).startswith(requests.GET.get('search')):
                for x in Friend.objects.sent_requests(user=requests.user):
                    if(User.objects.get(id=x.to_user_id).get_username() == i.get_username()):
                        uz_odoslane = True
                user_search.append(   (str(i.get_username()),uz_odoslane)  )
    context['user_search'] = user_search
    if (requests.GET.get('friendship_request') != None):
        other_user = User.objects.get(username=requests.GET.get('friendship_request'))
        Friend.objects.add_friend(
            requests.user,
            other_user)
    if (requests.GET.get('cancel_friendship_request') != None):
        other_user = User.objects.get(username=requests.GET.get('cancel_friendship_request'))
        for x in Friend.objects.sent_requests(user=requests.user):
            if (User.objects.get(id=x.to_user_id).get_username() == other_user.get_username()):
                x.cancel()
    if (requests.GET.get('friendship_accept') != None):
        other_user = User.objects.get(username=requests.GET.get('friendship_accept'))
        for x in Friend.objects.unrejected_requests(user=requests.user):
            if (User.objects.get(id=x.from_user_id).get_username() == other_user.get_username()):
                x.accept()
    if (requests.GET.get('friendship_reject') != None):
        other_user = User.objects.get(username=requests.GET.get('friendship_reject'))
        for x in Friend.objects.unrejected_requests(user=requests.user):
            if (User.objects.get(id=x.from_user_id).get_username() == other_user.get_username()):
                x.reject()

    context["all_friends"] = Friend.objects.friends(requests.user)
    context["all_unread_friend_requests"] = Friend.objects.unrejected_requests(user=requests.user)

    return render(requests, 'friends/index.html',context)


def register_request(request):
    if request.method == "POST":
        form = NewUserForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, "Registration successful.")
            return redirect('/')
        messages.error(request, "Unsuccessful registration. Invalid information.")
    form = NewUserForm()
    return render(request=request, template_name="main/register.html", context={"register_form": form})
